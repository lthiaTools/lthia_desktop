#temp notes
# os.path.abspath('cnemc.xls')


import os, inspect
from arcpy import *
from lthiaT import *

#Check out necessary Extentions
CheckOutExtension("spatial")

#Set Environment setting
p1 = os.path.dirname(os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))) # script directory111
arcpy.AddMessage(p1) # script directory

env.workspace = p1+"/lthiaTabular.gdb/"
env.overwriteOutput = True


#Parameters as Input
path = p1+"/lthiaTabular.gdb/"
Outline_feature = GetParameterAsText(0)
SoLuCN_raster  = GetParameterAsText(1)
Rainfall_feature = GetParameterAsText(2)
years = GetParameterAsText(3)
units = GetParameterAsText(4)
Output_feature = GetParameterAsText(5)
#years = 5

if int(years) > int(51):
    arcpy.AddMessage("\nPLEASE CHECK YEARS!!!\n SHOULD BE LESS THAN OR EQUAL TO 50 !!!\n")
    sys.exit(0)
if units.lower().strip() != 'us'.lower().strip() and units.lower().strip() != 'metric'.lower().strip():
    arcpy.AddMessage("\nPLEASE CHECK UNITS!!!\n SHOULD BE METRIC OR US !!!\n")
    sys.exit(0)    

#parameters
header_names_metric = ["Area(m^2)","Q-RunOffDepth(mm)","RunOffVolume(m^3)","EMCSuspendedSed(kg)","EMCPhosphorous(kg)","EMCNitrate(kg)","EMClead(kg)","EMCcopper(kg)","EMCZinc(kg)","Ecoli(MPN/100mL)"]
header_names_US = ["Area(acre)","Q-RunOffDepth(feet)","RunOffVolume(Acrefeet)","EMCSuspendedSed(USTonnes)","EMCPhosphorous(USTonnes)","EMCNitrate(USTonnes)","EMClead(Pounds)","EMCcopper(Pounds)","EMCZinc(Pounds)","Ecoli(MPN/100mL)"]
head_met_small = ["Area_m_2","QDepth_mm","RfVol_m_3","SSD_kg","P_kg","Ni_kg","Pb_kg","Cu_kg","Zn_kg","E_coli_Met"]
head_US_small =  ["Area_Acre","QDepth_ft","RfVol_Acft","SSD_Tonnes","P_Tonnes","Ni_Tonnes","Pb_Pounds","Cu_Pounds","Zn_Pounds","E_coli_US"]
temp = "img1"
counter = 0
field_value = ''
number = 0
row_count = SearchCursor(Outline_feature)
for rows_countx in row_count:
    number = number + 1
arcpy.AddMessage("number:"+str(number))
del row_count
del rows_countx
##for i in range(0,len(header_names_US)):  
##    try:
##        arcpy.AddMessage("\nUNITS:"+units+"\n")
##        if units.lower().strip() == 'Metric'.lower().strip():
##            AddField_management(Outline_feature,head_met_small[i] , "DOUBLE", "", "", "", header_names_metric[i], "NULLABLE", "REQUIRED")
##            arcpy.AddMessage("\nFIeld Added:"+head_met_small[i]+"\n")
##        if units.lower().strip() == 'US'.lower().strip():
##            AddField_management(Outline_feature,head_US_small[i] , "DOUBLE", "", "", "", header_names_US[i], "NULLABLE", "REQUIRED")
##            arcpy.AddMessage("\nFIeld Added:"+head_US_small[i]+"\n")
##    except:
##        arcpy.AddMessage("\nEXCEPT Count:"+str(i)+"\n")
try:
    AddField_management(Outline_feature,"CompYears" , "LONG", "", "", "", "", "NULLABLE", "REQUIRED")
except:
    AddMessage("Year field already exists")
if units.lower().strip() == 'Metric'.lower().strip():
    addFields(header_names_metric,Outline_feature,head_met_small)
else:
    addFields(header_names_US,Outline_feature,head_US_small)
rows = SearchCursor(Outline_feature)
for row in rows:
    try:
        att_no = row.getValue('FID')
        arcpy.AddMessage("\nRead FID"+str(att_no)+"\n")
        try:
            SelectLayerByAttribute_management(Outline_feature,"NEW_Selection","FID = "+str(att_no))
            field_value ='FID'
            arcpy.AddMessage("\nLayer select complete\n")
        except:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_tb(exc_traceback, limit=1, file=sys.stdout)
            traceback.print_exception(exc_type, exc_value, exc_traceback,limit=2, file=sys.stdout)        
    except:
        try:
            att_no = row.getValue('OBJECTID')
            try:
                SelectLayerByAttribute_management(Outline_feature,"NEW_Selection","OBJECTID = "+str(att_no))
                field_value ='OBJECTID'
            except:      
                exc_type, exc_value, exc_traceback = sys.exc_info()
                traceback.print_tb(exc_traceback, limit=1, file=sys.stdout)
                traceback.print_exception(exc_type, exc_value, exc_traceback,limit=2, file=sys.stdout) 
        except:
            arcpy.AddMessage("\nError in reading Object ID\n")
    AddMessage("Filed_value:"+field_value)
    try:
        AddMessage("XXXXX\n")
        if number != 1:
            AddMessage("XXXX inside\n")
            gp.ExtractByMask_sa(SoLuCN_raster, Outline_feature,p1+"/lthiaTabular.gdb/"+"img1")
            arcpy.AddMessage("\nExtract by mask DONE with att_no : "+str(att_no)+"\n")
            AddMessage("MULTIPLE POLY WITH SUB DIVISIONS\n")
        if number == 1:
            AddMessage("JUST ONE POLY NO SUB DIVISIONS\n")
            temp = SoLuCN_raster
        AddMessage("YYYYY\n")
    except:
        arcpy.AddMessage("\nExtract by mask NOT DONE with att_no :"+str(att_no)+"\n")
        sys.exit(0)
    try:
        gp.TabulateArea_sa(Rainfall_feature, "stationid", temp, "Value", path+"input_table", "30")
        arcpy.AddMessage("\nTabulate Area DONE with att_no :"+str(att_no)+"\n")
    except:
        arcpy.AddMessage("\nTabulate Area NOT DONE with att_no :"+str(att_no)+"\n")
        sys.exit(0)
    try:
        FileConverter(path , 'input_table', p1+"/Output/"+"input_table.txt" )
        arcpy.AddMessage("\nFile Converter DONE with att_no :"+str(att_no)+"\n")
    except:
        arcpy.AddMessage("\nFile Converter NOT DONE with att_no :"+str(att_no)+"\n")
        sys.exit(0)
##    try:
##        printer(p1+"/Output/",int(years),"input_table",field_value, units,att_no,head_met_small,head_US_small,Outline_feature)
##        arcpy.AddMessage("\nprinter DONE with att_no :"+str(att_no)+"\n")
##    except:
##        arcpy.AddMessage("\nprinter NOT DONE with att_no :"+str(att_no)+"\n")
##        sys.exit(0)
    printer(p1+"/Output/",int(years),"input_table",field_value, units,att_no,head_met_small,head_US_small,Outline_feature)
try:
    os.remove(p1+"/Output/"+"input_table"+".txt")
    Delete_management("input_table")
    Delete_management("img1")
except OSError, e:  ## if failed, report it back to the user ##
    print ("Error: %s - %s." % (e.filename,e.strerror))

collecter(p1+"/Output/")
del row
del rows
arcpy.SelectLayerByAttribute_management(Outline_feature, "CLEAR_SELECTION", "")
if units.lower().strip() == 'us'.lower().strip():
    DissolveFields(Outline_feature,Output_feature,head_US_small)
if units.lower().strip() == 'metric'.lower().strip():
    DissolveFields(Outline_feature,Output_feature,head_met_small)

del Outline_feature
del SoLuCN_raster
del Rainfall_feature
del Output_feature
del years
del counter
del att_no
del temp
del units
del header_names_metric
del header_names_US
del head_met_small
del head_US_small
del path
del field_value
del number
del p1
