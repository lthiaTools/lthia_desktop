#!/usr/bin/env python
from arcpy import *
import os, glob
import urllib2
import numpy
import csv
import math
from xlwt import *
import sys, traceback
import arcgisscripting


#
# Function1 :
# @param : polyFileName, avgYrs, condition, CNnum
#         polyFileName : String : Name of the text file
#         avgYrs : Integer : Number of years to average Q on
#         condition : Integer : Soil condition
#         CNnum : String : Just the integer CN whose Q is to be averaged
# @output : Qavg
# NOTE : Integers should NOT have a preceding 0 ex: 078 is wrong
# NOTE : All array indices start from 0
#


def AverageQ(polyFileName , avgYrs , condition , CNnum) :
    # Variables
    addr = "http://lthia.agriculture.purdue.edu/cligen/RunOff/"+polyFileName+"q.txt"
    CNstring = "CN"+str(CNnum)
    counter = 0
    simulatedYears = 0
    try :
        line1 = urllib2.urlopen(addr)
        firstLine = line1.readline().split("\t")
        simulatedYears = int((firstLine[4])[15:])
        secondLine = line1.readline().split("\t")
        # Finding the column num that matches the given CN num
        for element in secondLine :
             if element == CNstring :
                break
             counter = counter + 1
        # For loop ends here
        # Deleting variables that are no longer needed
        del element
        del secondLine
        del firstLine
        del CNstring
    except :
        print "Not able to access the URL."
    # Out of try catch block now
    # Reading the column values
    allQ = numpy.genfromtxt(line1, usecols = counter , dtype = float , skip_footer = simulatedYears - avgYrs )
    # Closing the file
    line1.close()
    # Deleting the variables that are no longer needed
    del addr
    del simulatedYears
    del counter
    del line1
    # Adding all the Q values to get the avg
    Qavg = 0.0
    for value in allQ :
        Qavg = Qavg + value
    # Deleting the variables that are no longer needed
    del value
    # Returning Qaverage, a float value from the function
    return Qavg/float(len(allQ))


# AverageQ function ends here
#
# Function2 :
# @param : path, LU_num, Qavg, area
#        
# @output : emc values
# NOTE : Integers should NOT have a preceding 0 ex: 078 is wrong
# NOTE : All array indices start from 0
#


def emcValues(path,LU_num,Qavg,area) :
    # Variables
    i = 0   #line number to get from cnemcgl file
    flag = 0 #loop exit
    # The length of the emc1 array is fixed because it is fixed in the file cnemcgl.csv
    emc1 = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    try :
        # x has the land use numbers present in the emc file.
        x = numpy.genfromtxt(path+"cnemcgl.csv",usecols=0,dtype=None,delimiter=',')
        #loop checks which line in file is needed as input for co-efficient calculations
        while flag == 0:
            if x[i] == LU_num:
                flag = 1
            i = i + 1
        # While loop ends here
    except :
        print "Possible errors :\n"
        print "1.Not able to access the file.\n"
        print "2.While loop has an error."
    try :
        reader = csv.reader(open(path+"cnemcgl.csv",'rt'))
        #loop run thereader till line i is found
        for j in range(0,i):
            y = reader.next()
        # y has the i'th line in it in an array
        # For loop ends here
        for i in range(2,(len(y)-1)):
            emc1[i-2] = float(y[i])*Qavg*area
            if i != (len(y)-2):
                emc1[i-2] = emc1[i-2]/1000
        # For loop ends here
    except :
        print "Possible errors :\n"
        print "1.Not able to open the file.\n"
        print "2.Either or both of the two for loops have an error."
    # Deleting the variables that are no longer needed
    del x
    del i
    del y
    del flag
    del reader
    del j
    # Returning emc1 array with float values in it
    return emc1


# emcValues function ends here
#
# Function3 :
# @param : None
#        
# @output : Generate a file with
# NOTE : Integers should NOT have a preceding 0 ex: 078 is wrong
# NOTE : All array indices start from 0
#



#Function starts here
def FileConverter( path , table , outputpath):
    gp = arcgisscripting.create()
    gp.workspace = path
    csvseparator = ','
    def print_exception():
        tb = sys.exc_info()[2]
        l = traceback.format_tb(tb)
        l.reverse()
        tbinfo = "".join(l)
        pymsg = "ERROR:\nTraceback Info:\n" + tbinfo + "Error Info:\n    " +  str(sys.exc_type)+ ": " + str(sys.exc_value) + ""
        print pymsg
        del tb
        del l
        del tbinfo
        del pymsg
    def get_fieldnames(fields, ignorefields=[]):
        fields_output = []
        for field in iter(fields.next, None):
            if not field.name in ignorefields:
                fields_output.append(field.name)
        del field
        return fields_output
    try:
        info = gp.describe(table)
        ignore_fields = [] # for example FID, Shape,... (case sensitive)
        fieldnames = get_fieldnames(info.fields, ignore_fields)
        print fieldnames
        rows = gp.searchcursor(table)
        output = []
        output.append(csvseparator.join(fieldnames))
        for row in iter(rows.next, None):
            outputrow = []
            for fieldname in fieldnames:
                outputrow.append(str(row.getvalue(fieldname)))
            outputrow = csvseparator.join(outputrow)
            output.append(outputrow)
        print 'found', str(len(output)), 'rows'
        f = open(outputpath, 'w')
        f.write('\n'.join(output))
        f.close()
    except:
        print_exception()
        gp.getmessages(2)
    
    del gp
    del csvseparator
    del info
    del ignore_fields
    del fieldnames
    del rows
    del output
    del row
    del outputrow
    del f
#function ends here

#function fillTable starts here
#writing to the attribute table in the outline layer
def fillTable(TotalArray, UnitsArray, selectedRow , filePath,field_value,years):
    AddMessage("flied_value:"+str(field_value))
    rows = arcpy.UpdateCursor(filePath)
    arcpy.AddMessage("I am here:")
    for row in rows:
        AddMessage("row value:")#+str(row.getValue(field_value)))
        if row.getValue(field_value) == selectedRow:
            arcpy.AddMessage("Row:"+str(row.getValue(field_value)))
            row.setValue("CompYears",years)
            for col in range(0,len(TotalArray)):
                arcpy.AddMessage("Total:"+str(TotalArray[col]))
                arcpy.AddMessage("Array:"+UnitsArray[col])
                row.setValue(UnitsArray[col],TotalArray[col])
            rows.updateRow(row)
    del row
    del rows
    
#function ends here

# Adding field names to Outline_feature table
def addFields(header,Outline_feature,head_small):
              
    for i in range(0,len(header)):  
        try:
            AddField_management(Outline_feature,head_small[i] , "DOUBLE", "", "", "", header[i], "NULLABLE", "REQUIRED")
            arcpy.AddMessage("\nFIeld Added:"+head_small[i]+"\n")
        except:
            arcpy.AddMessage("\nCouldn't add field names to the Outline_feature.\n")
            arcpy.AddMessage("\nEXCEPT Count:"+str(i)+"\n")
    del i
# Function addFields ends

#printer starts here
def printer(path,years,FileName_in,field_value , units , att_no, header_names_Metric,header_names_US,Outline_feature ) :
    # TODO : environment settings
    #
    #

    AddMessage("ENTER PRINTER:FIELD VALUE:"+str(field_value))
    fout2 = open(path+"LuSum"+str(att_no)+".csv",'w')
    #fout3 = open(path+"Total"+str(att_no)+".txt",'w')

    #Variables for keeping trac of where to print in the excel file
    row = 1
    col = 2
    colrange = 256
    sheet_no = 1
    xl = Workbook()
    fout1 = []
    fout1.append(xl.add_sheet(FileName_in+str(sheet_no)))
    
    #write header of file 2 and file 3
    fout2.write("Field Value,Field Name,Soil Type,Area (m^2),Q-RunOff Depth(mm),RunOff Volume (m^3),EMC-Total Suspended Sed (kg),EMC-Total Phosphorous (kg),EMC-Total Nitrate (kg),EMC-Total lead (kg),EMC-Total copper (kg),EMC-Total Zinc(kg),E-coli (MPN/100mL),\n")
    #if units.lower().strip() == 'Metric'.lower().strip():
    #    fout3.write("ID,Total Area (m^2),Q-RunOff Depth(mm),RunOff Volume (m^3),EMC-Total Suspended Sed (kg),EMC-Total Phosphorous (kg),EMC-Total Nitrate (kg),EMC-Total lead (kg),EMC-Total copper (kg),EMC-Total Zinc(kg),E-coli (MPN/100mL),\n")
   # if units.lower().strip() == 'US'.lower().strip():
    #    fout3.write("ID,Total Area (Acre),Q-RunOff Depth(feet),RunOff Volume (Acre feet),EMC-Total Suspended Sed (US Tonnes),EMC-Total Phosphorous (US Tonnes),EMC-Total Nitrate (US Tonnes),EMC-Total lead (Pounds),EMC-Total copper (Pounds),EMC-Total Zinc(Pounds),E-coli (MPN/100mL),\n")

    # An array with all the polygon file names ; first element in the array is 'StationID'
    poly_names = numpy.genfromtxt(path+FileName_in+".txt",delimiter=',',usecols=1,dtype = None)
    landUse_names = numpy.genfromtxt(path+"cnemcgl.csv",usecols=(0,1),dtype=None,delimiter=',')
    soil_names = ["SOIL:A","SOIL:B","SOIL:C","SOIL"];
    header_names = ["Area (m^2)","Q-RunOff Depth(mm)","RunOff Volume (m^3)","EMC Suspended Sed (kg)","EMC Phosphorous (kg)","EMC Nitrate (kg)","EMC lead (kg)","EMC copper (kg)","EMC Zinc(kg)","E-coli (MPN/100mL)"]
    #OUTPUT POLY NAMES AND BASIC STRUCTURE OF FIRST OUTPUT EXCEL FILE

    
    fout1[(sheet_no-1)].write(0,0,"Detailed Outputs",easyxf('font: bold true;''align: wrap true, vertical center, horizontal center;'))
    fout1[(sheet_no-1)].write(0,1,poly_names[0],easyxf('font: bold true;''align: wrap true, vertical center, horizontal center;'))
    fout1[(sheet_no-1)].col(0).width
    fout1[(sheet_no-1)].col(1).width
    for g in range (1,len(poly_names)):
        if col == colrange:
            sheet_no = 1 + sheet_no
            fout1.append(xl.add_sheet(FileName_in+str(sheet_no)))
            fout1[(sheet_no-1)].write(0,0,"Detailed Outputs",easyxf('font: bold true;''align: wrap true, vertical center, horizontal center;'))
            fout1[(sheet_no-1)].write(0,1,poly_names[0],easyxf('font: bold true;''align: wrap true, vertical center, horizontal center;'))
            col = 2
        fout1[(sheet_no-1)].write(0,col,poly_names[g],easyxf('font: bold true;''align: wrap true, vertical center, horizontal center;'))
        col = col + 1
    #resetting col number
    col = 2
    sheet_no = 1
    #xl.set_active_sheet(sheet_no)
    #active sheet
    
    # Output arrays
    Poly = []
    Sum = [ 0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ]
    Total = [ 0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ]
    # flag for while loop exit
    flag = 0
    i = 2

    # While loop starts here
    while flag == 0:
        try:
            # Every column of the input table with areas
            CN_areas = numpy.genfromtxt(path+FileName_in+".txt",delimiter=',',usecols=i,dtype = None)
            
            
            #
            # CN_num is always three digits
            CN_num = CN_areas[0][-3:]
            # Land use number
            LU_num = CN_areas[0][7:-3]
            #Soil number
            SO_num = CN_areas[0][6]
            if int(SO_num) > 4 or int(SO_num) < 1:
                arcpy.AddMessage("\nINVALID SOIL NUMBER:"+str(So_num)+".\n")
                sys.exit(0)
            #Get LU name
            for f in range (1,len(landUse_names)):
                if landUse_names[f][0] == LU_num:
                    LU_name = landUse_names[f][1]

            #Get Soil name
            SO_name = soil_names[(int(SO_num)-1)]
            

            #Print in xl file header for CN and the next line
            for o in range(0,len(fout1)):
                fout1[o].write_merge(row,row+9,0,0,CN_areas[0]+"-"+LU_name+"-"+SO_name,easyxf('font: bold true;''align: wrap true, vertical center, horizontal center;'))
                for p in header_names:
                    fout1[o].write(row,1,p)
                    row = row + 1
                row = row - 10
            
            
            # polygon iteration: each polygon area is iterated to generate ouput for first file and cumulate output for second file
            for j in range(1,len(poly_names)):
                # print poly_names[j]
                
            
                # qAverage  units mm
                qAverage =  AverageQ(poly_names[j] , years , 1 , CN_num)
                
                # qAverage = 10
                QArea = [float(CN_areas[j]),qAverage*float(CN_areas[j]),float(CN_areas[j])*qAverage*math.pow(10,-3)]
                #print QArea[0]
                if QArea[2] == 0.0:
                    QArea[1] = 0.0
            
                # emcValues units out g except last one in MNP
                emc = emcValues(path,LU_num,qAverage,float(CN_areas[j]))

                # Array to add to sum
                Poly = QArea + emc
                

                # Recalulating E-coil in MNP/100mL to output
                if QArea[1] != 0 :
                    emc [-1] = (emc[-1])/(1000*QArea[2]*10)

                # output to file: QArea[0],Qaverage,QArea[2],emc array
                if col == colrange:
                    col = 2
                    sheet_no = sheet_no + 1
                
                fout1[(sheet_no-1)].write(row,col,QArea[0])
                
                if QArea[0] == 0:
                    fout1[(sheet_no-1)].write((row+1),col,0)
                if QArea[0] != 0:
                    fout1[(sheet_no-1)].write((row+1),col,qAverage)
                
                fout1[(sheet_no-1)].write((row+2),col,QArea[2])

                rowTemp = row+3
                for z in emc:
                    fout1[(sheet_no-1)].write(rowTemp,col,z)
                    rowTemp = rowTemp + 1
                col = col + 1

                # add poly to sum
                for k in range(0,len(Poly)):
                    Sum[k] = Poly[k] + Sum[k]


            fout2.write(CN_areas[0]+","+LU_name+","+SO_name+",")
            #to go to the next CN number while output to first excel file
            row = row + 10
            col = 2
            sheet_no = 1
            #xl.set_active_sheet(sheet_no)

            #For EMC and Depth unit correction
            areaTemp = Sum[0]
            volumeTemp = Sum[2]
                      
            # Add Sum to total      
            for k in range(0,len(Sum)):
                    Total[k] = Sum[k] + Total[k]
                    # When I equal len-1 Change E-coli also chage the Qavg
                    if volumeTemp != 0:
                        if k==1:
                            Sum[k] = Sum[k]/areaTemp ;    
                        if k==(len(Sum) - 1):
                            Sum[k] = (Sum[k])/(1000*volumeTemp*10)
                    # Output Sum
                    fout2.write("%f"%(Sum[k])+",")
                    # Make sum 0
                    Sum[k] = 0.0
        
            

            fout2.write("\n")
        
        
        

        
            i = i + 1 ;
        except:
            flag = 1;
    # While loop ends here
    
    #Change E-coli and Qavg
    if Total[0] != 0:
        Total[1] = Total[1]/Total[0] ;
    if Total[2] != 0:
        Total[9] = (Total[9])/(1000*Total[2]*10)# All values are in m^2 , mm, m^3 , kg, kg, kg, kg, kg, kg, MPN/100 ml
    #
    # Use the parameter "units" in the if statemet
    # If the user wants in acre feet, uncomment the line below
    if units.lower().strip() == 'US'.lower().strip():
        Total  = unitsConverter( Total )
        fillTable(Total, header_names_US, att_no , Outline_feature,field_value,years)
    if units.lower().strip() == 'Metric'.lower().strip():
        fillTable(Total, header_names_Metric, att_no , Outline_feature,field_value,years)

   # fout3.write(str(att_no)+",")
   # for i in Total:
    #    fout3.write("%f"%(i)+",")


    #save excel file


    xl.save(path+"Poly"+str(att_no)+".xls")
    
    # Deleting the variables that are no longer needed
    del poly_names
    del Poly
    del Sum
    del Total
    del qAverage
    del flag
    del i
    del QArea
    del emc
    del CN_num
    del LU_num
    del CN_areas
    del fout1
    del fout2
    #del fout3
    del LU_name
    del landUse_names
    del SO_num
    del soil_names
    del xl
    del col
    del row
    del colrange
    del sheet_no
    del areaTemp
    del volumeTemp
    del rowTemp
    del header_names
# printer function ends here
#
# Function to convert the units in acre-feet
def unitsConverter( array ):
    # All values are in : m^2  , mm   , m^3       , kg   , kg   , kg   , kg     , kg     , kg     , MPN/100 ml
    # To convert into   : acre , feet , acre-feet , tons , tons , tons , pounds , pounds , pounds , MPN/100 ml  

    converted = [ 0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ,0.0 ]

    # 1 acre = 4047 m^2
    first = array[0]
    first = float(first)/float(4047)
    converted[0] = first

    # 1 foot = 304.8 mm
    second = array[1]
    second = float(second)/float(304.8)
    converted[1] = second

    # 1 acre-foot = 1233.481855 m^3
    third = array[2]
    third = float(third)/float(1233.481855)
    converted[2] = third

    del first
    del second
    del third
    
    for x in range(3,6):
    # 1 US ton = 907.18475 kg
        element1 = array[x]
        element1 = float(element1)/float(907.18475)
        converted[x] = element1

    for y in range(6,9):
    # 1 US pound = 0.45359 kg
        element2 = array[y]
        element2 = float(element2)/float(0.45359)
        converted[y] = element2

    converted[9] = array[9]
    del x
    del y
    del element1
    del element2

    return converted
    
# unitsConverter function ends here
#
# main function to run the entire code
def main():

    # path = getParameterAsText(0)
    path = "//shay.ecn.purdue.edu/akochar/pchome/.pcprefs/Desktop/work/lthai/"
    # FileName_in = getParameterAsText(2)
    # years = getParameterAsText(1)
    # units = getParameterAsText(3)

    FileConverter(r'E:\LthiaToolbox105\test.gdb' , 'SoLuCn_2011', path+"SOLUCN1.txt" )
    
    FileName_in = "SOLUCN"
    years = 5
    units = 'Metric' # or US for the needed units
    try:
        printer(path,years,FileName_in,1, units, 1)
    except:
        print("ERROR")
    try:
        os.remove(path+FileName_in+".txt")
    except OSError, e:  ## if failed, report it back to the user ##
        print ("Error: %s - %s." % (e.filename,e.strerror))
    
    del FileName_in
    del path
    del years
    del units
    
#main function ends here

def DissolveFields(inputFeature, outputFeature, FL ):
    # Process: Dissolve
    Qtemp = 0
    Etemp = 0
    arcpy.Dissolve_management(inputFeature, outputFeature, "CompYears",FL[0]+" SUM;"+FL[1]+" SUM;"+FL[2]+" SUM;"+FL[3]+" SUM;"+FL[4]+" SUM;"+FL[5]+" SUM;"+FL[6]+" SUM;"+FL[7]+" SUM;"+FL[8]+" SUM;"+FL[9]+" SUM", "MULTI_PART", "DISSOLVE_LINES")
    row_count = SearchCursor(inputFeature)
    for row0 in row_count:
        Qtemp = (row0.getValue(FL[0]) * row0.getValue(FL[1])) + Qtemp
        Etemp = (row0.getValue(FL[0]) * row0.getValue(FL[9])) + Etemp
    del row_count
    del row0
    AddMessage("Qtemp:"+str(Qtemp))
    AddMessage("Etemp:"+str(Etemp))
    rows = UpdateCursor(outputFeature)
    for row1 in rows:
        Qtemp = Qtemp/row1.getValue("SUM_"+FL[0])
        Etemp = Etemp/row1.getValue("SUM_"+FL[0])
        row1.setValue("SUM_"+FL[1],Qtemp)
        row1.setValue("SUM_"+FL[9],Etemp)
        rows.updateRow(row1)
    del rows
    del row1
    
    AddMessage("Qtemp after division:"+str(Qtemp))
    AddMessage("Etemp after division:"+str(Etemp))
#function to test dissolveFields
def main_dissolve():
    # Local variables:
    testsheds0630 = "testsheds0630"
    output_feature1 = "E:\\US_lthia_comp\\lthiaTabular.gdb\\output_feature1"
    DissolveFields(testsheds0630,output_feature1,["Area_m_2","QDepth_mm","RfVol_m_3","SSD_kg","P_kg","Ni_kg","Pb_kg","Cu_kg","Zn_kg","E_coli_Met"])

#collector function starts here
def collecter(path1):
    counter = 0 ;
    w = Workbook()
    for x in glob.glob(path1+'*.csv'):
        string = str(path1)
        if x != string[:-1]+'\cnemcgl.csv' and x != string[:-1]+'\cnluso.csv' :
            print x
            ws = w.add_sheet('test'+str(counter))
            counter = counter + 1
            print counter
            with open(x,'rb') as f:
                reader = csv.reader(f)
                for r, row in enumerate(reader):
                    for c,col in enumerate(row):
                        ws.write(r,c,col)
            os.remove(x)
    w.save(path1+"LthiaOutputbyPoly.xls")
    #w.save(path1+"Tab_by _poly"+str(counter)+".xls")
    del ws
    del w
    del x
    del counter
    del reader
#Function to test collecter
def collectmain():
    #collect("R:/Desktop/work/lthia")
    collecter(r"//shay.ecn.purdue.edu/akochar/pchome/.pcprefs/Desktop/work/lthai/")
    print 'finished'





