# Import arcpy module
import arcpy

# Import system modules
import sys, os, string, traceback, urllib2, datetime, calendar
from dateutil.relativedelta import relativedelta

arcpy.env.overwriteOutput = 1

inputLayer = arcpy.GetParameterAsText(0)

outputLayer = arcpy.GetParameterAsText(1)

def main():
    arcpy.CreateThiessenPolygons_analysis (inputLayer, outputLayer, "ALL")


    #tableCount = 0 
    # cursor = arcpy.da.UpdateCursor(watershed_CountyIntersect,["avg_rain","precip_table","table_unit"]) 
    # for row in cursor:
        # extractPrecip(pcpData,tablename,row,tableCount)
        # cursor.updateRow(row)
    
    

if __name__ == "__main__":
    main()