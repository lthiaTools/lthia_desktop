# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# selectCountyForWatershed.py
# Description: 
# ---------------------------------------------------------------------------

# Set the necessary product code
# import arcinfo


# Import arcpy module
import arcpy

# Import system modules
import sys, os, string, traceback, urllib2, datetime, calendar, re
from dateutil.relativedelta import relativedelta


# Instantiate Geoprocessor
arcpy.env.overwriteOutput = 1


#Inputs
watershed = arcpy.GetParameterAsText(0) #input watershed

arcpy.AddMessage("watershed = " + watershed)

yearcount = arcpy.GetParameter(1)

#detailCounty = arcpy.GetParameterAsText(1)

#userfile = arcpy.GetParameterAsText(2)

#rainunit = arcpy.GetParameterAsText(3)

outputLayer = arcpy.GetParameterAsText(2)

# Local variables:
#watershed = "watershed"

#DetailCounty = "DetailCounty"


#watershed_FeatureToPoint = "L:\\arcgis_lthia\\data\\scratch.gdb\\watershed_FeatureToPoint"

#watershed_CountyIntersect = "C:\\WorkSpace\\cs497\\data\\lthiamod1.gdb\\watershed_CountyIntersect"
watershed_CountyIntersect = outputLayer



#precipcounty = "L:\\arcgis_lthia\\data\\precipcounty"

precipcounty = "precipcounty"
precipcounty2 = "precipcounty2"

#arcpy.env.workspace = "C:\\WorkSpace\\cs497\\data"
arcpy.env.workspace = os.path.dirname(os.path.realpath(outputLayer))


#regex = re.compile(
#        '((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)', re.IGNORECASE)

month_dict = {"Jan.":1,"Feb.":2,"Mar.":3,"Apr.":4, "May":5, "June":6, \
    "July":7,"Aug.":8,"Sept.":9,"Oct.":10,"Nov.":11,"Dec.":12}
avgRain = []


def main():
    tableCount = 0       
    
    arcpy.AddMessage("QUERYING CLIGEN")

    arcpy.Intersect_analysis ([os.path.join(os.path.dirname(os.path.abspath(__file__)),'lthia.gdb\CligenFeature'),watershed], watershed_CountyIntersect, "ALL", "", "")


    arcpy.AddField_management(watershed_CountyIntersect, "avg_rain", "FLOAT", "", "", "", "avg_rain", "NULLABLE", "REQUIRED")
    arcpy.AddField_management(watershed_CountyIntersect, "precip_table", "STRING", "", "", "", "precip_table", "NULLABLE", "REQUIRED")
    arcpy.AddField_management(watershed_CountyIntersect, "table_unit", "STRING", "", "", "", "table_unit", "NULLABLE", "REQUIRED")
    #cursor = arcpy.da.UpdateCursor(watershed_CountyIntersect,["avg_rain","precip_table","table_unit","UR_pcp"]) 
    cursor = arcpy.da.UpdateCursor(watershed_CountyIntersect,["avg_rain","precip_table","table_unit","URL"]) 

    urlList = []
    for row in cursor:   
        #tablename = "%s\\table%d.csv" % (arcpy.env.workspace,tableCount)
        tablename = "%s\\%s_table%d.csv" % (arcpy.env.workspace,os.path.basename(outputLayer),tableCount)

        
        if "http" in row[3]:    
#           if regex.match(row[3]):
            arcpy.AddMessage("\nQuerying file at: " + row[3])
            req = urllib2.Request(row[3])
            response = urllib2.urlopen(req)
            pcpData = response.read()
        else:
            f = open(row[3], 'r')
            pcpData = f.read()
            f.close()
            
        extractPrecip(pcpData,tablename,row,tableCount)
        
        tableCount += 1
        cursor.updateRow(row)

    for i in range(tableCount):
        #tablename = "%s\\table%d.csv" % (arcpy.env.workspace,i)
        tablename = "%s\\%s_table%d.csv" % (arcpy.env.workspace,os.path.basename(outputLayer),i)
        arcpy.TableToTable_conversion(tablename, arcpy.env.workspace, "%s_table%d"%(os.path.basename(outputLayer),i))
     
 
def extractPrecip(pcpData,output_table_name,input_row, tableCount):
    f = open(output_table_name, 'w')
    Date = []
    # Yr = []
    # Mo = []
    # Da = []
    pcp = []
    start_year = 0
            
    # if 'end' in pcpData:
    pcpData = pcpData.split('\n')
    data = pcpData[15:]
    header = pcpData[:15]
    
    temp = data[0].split()
    if int(temp[2]) < 1000:
        temp[2] = str(int(temp[2]) + 1900)
    start = datetime.date(int(temp[2]), int(temp[1]), int(temp[0]))
    start_year = start
    line = header[5].split()
    temp = data[-1].split()
    n = 2
    while not temp:
        temp = data[n * -1].split()
        n+=1
    if int(temp[2]) < 1000:
        temp[2] = str(int(temp[2]) + 1900)
    end = datetime.date(int(temp[2]), int(temp[1]), int(temp[0]))
    #end = datetime.date(int(line[4]), month_dict.get(line[2], 1), int(line[3]))
    line = header[4].split()
    yearcnt = int(line[5])
    if yearcount > 0:
        yearcnt = min(yearcnt, yearcount)
    arcpy.AddMessage('Restricted years to ' + str(yearcnt))
    years = [[] for x in xrange(yearcnt)]
    # inc = datetime.timedelta(1)
    line = header[14].split()
    rainunit = line[0].replace("(","").replace(")","")
    
    for i in range(len(data)) :
        line = data[i]
        line = line.split()
        #arcpy.AddMessage('line: ' + str(line))
        if line and int(line[2]) > yearcnt:
            break
        if line and not (int(line[0]) == 29 and int(line[1]) == 2) :
            if int(line[2]) < 1000:
                line[2] = str(int(line[2]) + 1900)
            curdate = datetime.date(int(line[2]), int(line[1]), int(line[0]))
            curdatestr = curdate.strftime("%Y%m%d")
            Date.append(curdatestr)
            # Yr.append(curdate[0:4])
            # Mo.append(curdate[4:6])
            # Da.append(curdate[6:])
            pcp.append(float(line[3]))
            years[curdate.year - start.year].append(float(line[3]))
            # arcpy.AddMessage(str(curdate.year - start.year))
            #arcpy.AddMessage(curdate[0:4] + ' ' + curdate[4:6] + ' ' + curdate[6:] + ' ' + line[3])
        
        # for i in range(len(data)):
            # line = data[i].split()
            # for j in range(len(line)):
                # years[j].append(line[j])

        # for i in range(yearcnt):
            # for j in range(len(years[i])):
                # if start.month == 3 and start.day == 1 and not calendar.isleap(start.year):
                    # start += inc
                    # continue
                
                # curdate = start.strftime("%Y%m%d")
                # Date.append(curdate)
                # Yr.append(curdate[0:4])
                # Mo.append(curdate[4:6])
                # Da.append(curdate[6:])
                # pcp.append(float(years[i][j]))
                # start += inc
        
    # else:
        # pcpData = pcpData.split('\n')
        
        # for i in range(len(pcpData)) :
            # pcpData[i] = pcpData[i].replace(' ',',')
            # pcpData[i] = pcpData[i].replace('\t',',')
            # pcpData[i] = pcpData[i].split(',')
            # pcpData[i] = filter(None, pcpData[i])
            # if pcpData[i] and 1 < len(pcpData[i][0]) :
                # Date.append(str(pcpData[i][0]))
                # Yr.append(pcpData[i][0][0:4])
                # Mo.append(pcpData[i][0][4:6])
                # Da.append(pcpData[i][0][6:])
                # pcp.append(float(pcpData[i][1]))

    
    rainTotal = 0.0            
    for day in pcp:
        rainTotal += day
    arcpy.AddMessage("raintotal = %f" % rainTotal)
    avgRain.append(rainTotal/12.0)    
    input_row[0] = rainTotal/12.0
    
    yearcounter = 1#int(start_year.strftime("%Y"))
    for i in range(yearcnt-1):
        f.write('yr_%s,'%yearcounter)
        yearcounter += 1
    f.write('yr_%s'%yearcounter)    
    f.write('\n')  
    
    for j in range(len(years[i])):
        for i in range(yearcnt-1):
            f.write("%s," % years[i][j])
        f.write("%s" % years[i+1][j])    
        f.write('\n')    

        
    #input_row[1] = "table%d"%tableCount
    input_row[1] = "%s_table%d"%(os.path.basename(outputLayer),tableCount)
    
    input_row[2] = rainunit
    
    f.close()

        
    arcpy.AddMessage(avgRain)
    return None
 
if __name__ == "__main__":
    main()