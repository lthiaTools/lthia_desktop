# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# selectCountyForWatershed.py
# Description: 
# ---------------------------------------------------------------------------

# Set the necessary product code
# import arcinfo


# Import arcpy module
import arcpy

# Import system modules
import sys, os, string, traceback, urllib2, datetime, calendar, re
from dateutil.relativedelta import relativedelta


# Instantiate Geoprocessor
arcpy.env.overwriteOutput = 1


#Inputs
watershed = arcpy.GetParameterAsText(0) #input watershed

arcpy.AddMessage("watershed = " + watershed)

detailCounty = arcpy.GetParameterAsText(1)

userfile = arcpy.GetParameterAsText(2)

rainunit = arcpy.GetParameterAsText(3)

outputLayer = arcpy.GetParameterAsText(4)

# Local variables:
#watershed = "watershed"

#DetailCounty = "DetailCounty"


#watershed_FeatureToPoint = "L:\\arcgis_lthia\\data\\scratch.gdb\\watershed_FeatureToPoint"

#watershed_CountyIntersect = "C:\\WorkSpace\\cs497\\data\\lthiamod1.gdb\\watershed_CountyIntersect"
watershed_CountyIntersect = outputLayer



#precipcounty = "L:\\arcgis_lthia\\data\\precipcounty"

precipcounty = "precipcounty"
precipcounty2 = "precipcounty2"

#arcpy.env.workspace = "C:\\WorkSpace\\cs497\\data"
arcpy.env.workspace = os.path.dirname(os.path.realpath(outputLayer))


# Process: Feature To Point
#arcpy.FeatureToPoint_management(watershed, watershed_FeatureToPoint, "INSIDE")

# Process: Select Layer By Location
#arcpy.SelectLayerByLocation_management(detailCounty, "INTERSECT", watershed_FeatureToPoint, "", "NEW_SELECTION")

# Process: Select Layers By Intersection
#arcpy.AddMessage("arcpy.Intersect_analysis ([" + detailCounty + "," + watershed + "],....)")

#regex = re.compile(
#        '((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)', re.IGNORECASE)

month_dict = {"Jan.":1,"Feb.":2,"Mar.":3,"Apr.":4, "May":5, "June":6, \
    "July":7,"Aug.":8,"Sept.":9,"Oct.":10,"Nov.":11,"Dec.":12}
avgRain = []


def main():
    tableCount = 0       

    if userfile != "" :
        arcpy.AddMessage("USER SUBMITTED PRECIP FILE: " + userfile)
        arcpy.CopyFeatures_management (watershed, watershed_CountyIntersect, "", "", "", "")
        arcpy.AddField_management(watershed_CountyIntersect, "avg_rain", "FLOAT", "", "", "", "avg_rain", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(watershed_CountyIntersect, "precip_table", "STRING", "", "", "", "precip_table", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(watershed_CountyIntersect, "table_unit", "STRING", "", "", "", "table_unit", "NULLABLE", "REQUIRED")
        f = open(userfile, 'r')
        pcpData = f.read()
        f.close()
        #tablename = "%s\\table%d.csv" % (arcpy.env.workspace,tableCount)
        tablename = "%s\\%s_table%d.csv" % (arcpy.env.workspace,os.path.basename(outputLayer),tableCount)
        
        cursor = arcpy.da.UpdateCursor(watershed_CountyIntersect,["avg_rain","precip_table","table_unit"]) 
        for row in cursor:
            extractPrecip(pcpData,tablename,row,tableCount)
            cursor.updateRow(row)
        
        tableCount = 1
        
    else:
        arcpy.AddMessage("USER DIDNT SUMBIT A PRECIP FILE...\nQUERYING LTHIA")

        arcpy.Intersect_analysis ([detailCounty,watershed], watershed_CountyIntersect, "ALL", "", "")

        # Process: Export Feature Attribute to ASCII

        #arcpy.ExportXYv_stats(watershed_CountyIntersect, "UR_pcp", "COMMA", precipcounty2, "NO_FIELD_NAMES")
        #arcpy.ExportXYv_stats(watershed_CountyIntersect, "names3_t_3", "COMMA", precipcounty2, "NO_FIELD_NAMES")

        arcpy.AddField_management(watershed_CountyIntersect, "avg_rain", "FLOAT", "", "", "", "avg_rain", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(watershed_CountyIntersect, "precip_table", "STRING", "", "", "", "precip_table", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(watershed_CountyIntersect, "table_unit", "STRING", "", "", "", "table_unit", "NULLABLE", "REQUIRED")
        #cursor = arcpy.da.UpdateCursor(watershed_CountyIntersect,["avg_rain","precip_table","table_unit","UR_pcp"]) 
        cursor = arcpy.da.UpdateCursor(watershed_CountyIntersect,["avg_rain","precip_table","table_unit","names3_t_3"]) 

        urlList = []
        for row in cursor:   
            #tablename = "%s\\table%d.csv" % (arcpy.env.workspace,tableCount)
            tablename = "%s\\%s_table%d.csv" % (arcpy.env.workspace,os.path.basename(outputLayer),tableCount)

            
            if "http" in row[3]:    
    #           if regex.match(row[3]):
		arcpy.AddMessage("\nQuerying file at: " + row[3])
                req = urllib2.Request(row[3])
                response = urllib2.urlopen(req)
                pcpData = response.read()
            else:
                f = open(row[3], 'r')
                pcpData = f.read()
                f.close()
                
            extractPrecip(pcpData,tablename,row,tableCount)
            
            tableCount += 1
            cursor.updateRow(row)
            
            ##################
            # Date = []
            # Yr = []
            # Mo = []
            # Da = []
            # pcp = []
            # start_year = 0
            
            # if 'end' in pcpData:
                # pcpData = pcpData.split('end')
                # data = pcpData[1].split("\n")
                # header = pcpData[0].split("\n")
                # line = header[4].split()
                # start = datetime.date(int(line[4]), month_dict.get(line[2], 1), int(line[3]))
                # start_year = start
                # line = header[5].split()
                # end = datetime.date(int(line[4]), month_dict.get(line[2], 1), int(line[3]))
                # line = header[6].split()
                # yearcnt = int(line[1])
                # years = [[] for x in xrange(yearcnt)]
                # inc = datetime.timedelta(1)
                
                # for i in range(len(data)):
                    # line = data[i].split()
                    # for j in range(len(line)):
                        # years[j].append(line[j])

                # for i in range(yearcnt):
                    # for j in range(len(years[i])):
                        # if start.month == 3 and start.day == 1 and not calendar.isleap(start.year):
                            # start += inc
                            # continue
                        
                        # curdate = start.strftime("%Y%m%d")
                        # Date.append(curdate)
                        # Yr.append(curdate[0:4])
                        # Mo.append(curdate[4:6])
                        # Da.append(curdate[6:])
                        # pcp.append(float(years[i][j]))
                        # start += inc
                
            # else:
                # pcpData = pcpData.split('\n')
                
                # for i in range(len(pcpData)) :
                    # pcpData[i] = pcpData[i].replace(' ',',')
                    # pcpData[i] = pcpData[i].replace('\t',',')
                    # pcpData[i] = pcpData[i].split(',')
                    # pcpData[i] = filter(None, pcpData[i])
                    # if pcpData[i] and 1 < len(pcpData[i][0]) :
                        # Date.append(str(pcpData[i][0]))
                        # Yr.append(pcpData[i][0][0:4])
                        # Mo.append(pcpData[i][0][4:6])
                        # Da.append(pcpData[i][0][6:])
                        # pcp.append(float(pcpData[i][1]))

            
            # rainTotal = 0.0            
            # for day in pcp:
                # rainTotal += day
            # arcpy.AddMessage("raintotal = %f" % rainTotal)
            # avgRain.append(rainTotal/12.0)    
            # row[1] = rainTotal/12.0
            
            # yearcounter = int(start_year.strftime("%Y"))
            # for i in range(yearcnt-1):
                # f.write('yr_%s,'%yearcounter)
                # yearcounter += 1
            # f.write('yr_%s'%yearcounter)    
            # f.write('\n')    
            
            # for j in range(len(years[i])):
                # for i in range(yearcnt-1):
                    # f.write("%s," % years[i][j])
                # f.write("%s" % years[i+1][j])    
                # f.write('\n')    

                
            # row[2] = "table%d"%tableCount
            
            # f.close()
            # tableCount += 1
            # cursor.updateRow(row)
            
        # arcpy.AddMessage(avgRain)

    for i in range(tableCount):
        #tablename = "%s\\table%d.csv" % (arcpy.env.workspace,i)
        tablename = "%s\\%s_table%d.csv" % (arcpy.env.workspace,os.path.basename(outputLayer),i)
        arcpy.TableToTable_conversion(tablename, arcpy.env.workspace, "%s_table%d"%(os.path.basename(outputLayer),i))
     
 
def extractPrecip(pcpData,output_table_name,input_row, tableCount):
    f = open(output_table_name, 'w')
    Date = []
    Yr = []
    Mo = []
    Da = []
    pcp = []
    start_year = 0
            
    if 'end' in pcpData:
        pcpData = pcpData.split('end')
        data = pcpData[1].split("\n")
        header = pcpData[0].split("\n")
        line = header[4].split()
        start = datetime.date(int(line[4]), month_dict.get(line[2], 1), int(line[3]))
        start_year = start
        line = header[5].split()
        end = datetime.date(int(line[4]), month_dict.get(line[2], 1), int(line[3]))
        line = header[6].split()
        yearcnt = int(line[1])
        years = [[] for x in xrange(yearcnt)]
        inc = datetime.timedelta(1)
        
        for i in range(len(data)):
            line = data[i].split()
            for j in range(len(line)):
                years[j].append(line[j])

        for i in range(yearcnt):
            for j in range(len(years[i])):
                if start.month == 3 and start.day == 1 and not calendar.isleap(start.year):
                    start += inc
                    continue
                
                curdate = start.strftime("%Y%m%d")
                Date.append(curdate)
                Yr.append(curdate[0:4])
                Mo.append(curdate[4:6])
                Da.append(curdate[6:])
                pcp.append(float(years[i][j]))
                start += inc
        
    else:
        pcpData = pcpData.split('\n')
        
        for i in range(len(pcpData)) :
            pcpData[i] = pcpData[i].replace(' ',',')
            pcpData[i] = pcpData[i].replace('\t',',')
            pcpData[i] = pcpData[i].split(',')
            pcpData[i] = filter(None, pcpData[i])
            if pcpData[i] and 1 < len(pcpData[i][0]) :
                Date.append(str(pcpData[i][0]))
                Yr.append(pcpData[i][0][0:4])
                Mo.append(pcpData[i][0][4:6])
                Da.append(pcpData[i][0][6:])
                pcp.append(float(pcpData[i][1]))

    
    rainTotal = 0.0            
    for day in pcp:
        rainTotal += day
    arcpy.AddMessage("raintotal = %f" % rainTotal)
    avgRain.append(rainTotal/12.0)    
    input_row[0] = rainTotal/12.0
    
    yearcounter = int(start_year.strftime("%Y"))
    for i in range(yearcnt-1):
        f.write('yr_%s,'%yearcounter)
        yearcounter += 1
    f.write('yr_%s'%yearcounter)    
    f.write('\n')    
    
    for j in range(len(years[i])):
        for i in range(yearcnt-1):
            f.write("%s," % years[i][j])
        f.write("%s" % years[i+1][j])    
        f.write('\n')    

        
    #input_row[1] = "table%d"%tableCount
    input_row[1] = "%s_table%d"%(os.path.basename(outputLayer),tableCount)
    
    input_row[2] = rainunit
    
    f.close()

        
    arcpy.AddMessage(avgRain)
    return None
 
if __name__ == "__main__":
    main()
 
 
 
 
 
 
# countyRainURLs = open(os.path.join(arcpy.env.workspace,precipcounty2),'r')
# for line in countyRainURLs:
    # entries = line.split(',')
    # urlList.append(entries[2])
# countyRainURLs.close()

# arcpy.AddMessage(urlList)
 
 
# for url in urlList:    
    # req = urllib2.Request(url)
    # response = urllib2.urlopen(req)
    # the_page = response.read()
    # pcpData = the_page
    
    # pcp = []
    
    # if 'end' in pcpData:
        # pcpData = pcpData.split('end')
        # data = pcpData[1].split("\n")
        # header = pcpData[0].split("\n")
        # line = header[4].split()
        # start = datetime.date(int(line[4]), month_dict.get(line[2], 1), int(line[3]))
        # line = header[5].split()
        # end = datetime.date(int(line[4]), month_dict.get(line[2], 1), int(line[3]))
        # line = header[6].split()
        # yearcnt = int(line[1])
        # years = [[] for x in xrange(yearcnt)]
        # inc = datetime.timedelta(1)
        
        # for i in range(len(data)):
            # line = data[i].split()
            # for j in range(len(line)):
                # years[j].append(line[j])

        # for i in range(yearcnt):
            # for j in range(len(years[i])):
                # if start.month == 3 and start.day == 1 and not calendar.isleap(start.year):
                    # start += inc
                    # continue
                # pcp.append(float(years[i][j]))
                # start += inc
        
    # else:
        # pcpData = pcpData.split('\n')
        
        # for i in range(len(pcpData)) :
            # pcpData[i] = pcpData[i].replace(' ',',')
            # pcpData[i] = pcpData[i].replace('\t',',')
            # pcpData[i] = pcpData[i].split(',')
            # pcpData[i] = filter(None, pcpData[i])
            # if pcpData[i] and 1 < len(pcpData[i][0]) :
                # pcp.append(float(pcpData[i][1]))

    
    # rainTotal = 0.0            
    # for day in pcp:
        # rainTotal += day
    # arcpy.AddMessage("raintotal = %f" % rainTotal)
    # avgRain.append(rainTotal/12.0)    

# arcpy.AddMessage(avgRain)

#arcpy.AddField_management(watershed_CountyIntersect, "avg_rain", "FLOAT", "", "", "", "avg_rain", "NULLABLE", "REQUIRED")

















