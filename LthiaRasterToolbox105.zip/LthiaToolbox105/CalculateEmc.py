def print_exception():
    
    tb = sys.exc_info()[2]
    l = traceback.format_tb(tb)
    l.reverse()
    tbinfo = "".join(l)
    arcpy.AddError("\n----------ERROR Start-------------------\n")
    arcpy.AddError("Traceback Info: \n" + tbinfo + "Error Info: \n    " +  str(sys.exc_type)+ ": " + str(sys.exc_value) + "")
    arcpy.AddError("----------ERROR End-------------------- \n")

def average(l):
    avg = 0
    cnt = 0
    for i in l:
        cnt += 1
        avg += i
    return avg / cnt
    
## ================================================================================================================
# Import system modules
import sys, os, string, traceback
import arcpy as gp
arcpy.AddMessage("Establishing Data Values")
# #landuse,CN-A,CN-B,CN-C,CN-D,EMC-TSS(mg/L),EMC-TP(mg/L),EMC-TN(mg/L),EMC-TLead(ug/L),EMC-TCopper(ug/L),EMC-TZinc(ug/L),E-coli(MPN/100mL)
# EMCs = {
# 11:['Open water',0,0,0,0,41,0.57,1.82,9,15,80,21813],
# 12:['Perennial Ice/Snow',0,0,0,0,41,0.57,1.82,9,15,80,21813],
# 21:['Developed Open Space',77,86,91,94,57.9,0.35,1.86,12,13.9,141,10931.33],
# 22:['Developed Low Intensity',46,65,77,82,41,0.57,1.82,9,15,80,10931.33],
# 23:['Developed Medium Intensity',62,75,84,87,41,0.57,1.82,9,15,80,10931.33],
# 24:['Developed High Intensity',77,85,90,92,41,0.57,1.82,9,15,80,10931.33],
# 31:['Barren Land',77,86,91,94,57.9,0.35,1.86,12,13.9,141,10931.33],
# 32:['Unconsolidated Shore',0,0,0,0,41,0.57,1.82,9,15,80,21813],
# 41:['Deciduous Forest',45,66,75,83,57.9,0.22,1.57,11,11,60,3750],
# 42:['Evergreen Forest',45,66,75,83,57.9,0.22,1.57,11,11,60,3750],
# 43:['Mixed Forest',45,66,75,83,57.9,0.22,1.57,11,11,60,3750],
# 51:['Dwarf Scrub',45,66,75,83,57.9,0.22,1.57,11,11,60,3750],
# 52:['Scrub/Shrub',45,66,75,83,57.9,0.22,1.57,11,11,60,3750],
# 71:['Grassland/Herbaceous',68,79,86,89,73.5,0.22,1.86,11,11,60,3750],
# 72:['Sedge Herbaceous',68,79,86,89,73.5,0.22,1.86,11,11,60,3750],
# 81:['Pasture/Hay',68,79,86,89,73.5,0.22,1.86,11,11,60,3750],
# 82:['Cultivated Crops',64,75,82,85,107,1.3,4.4,1.5,1.5,16,188],
# 90:['Woody Wetlands',0,0,0,0,0,0,0,0,0,0,0],
# 91:['Palustrine Forested Wetland',0,0,0,0,0,0,0,0,0,0,0],
# 92:['Palustrine Scrub/Shrub',0,0,0,0,0,0,0,0,0,0,0],
# 93:['Estuarine Forested Wetlands',0,0,0,0,0,0,0,0,0,0,0],
# 94:['Estuarine Scrub/Shrub',0,0,0,0,0,0,0,0,0,0,0],
# 95:['Emergent Herbaceous Wetland',0,0,0,0,0,0,0,0,0,0,0],
# 96:['Palustrine Emergent Wetland (Persistent)',0,0,0,0,0,0,0,0,0,0,0],
# 97:['Palustrine Emergent Wetland',0,0,0,0,0,0,0,0,0,0,0],
# 98:['Palustrine Aquatic Bed',0,0,0,0,0,0,0,0,0,0,0],
# 99:['Estuarine Aquatic Bed',0,0,0,0,0,0,0,0,0,0,0],}
emcfile = open(os.path.join(os.path.dirname(os.path.realpath(__file__)),'cnemc.csv'), 'r')
EMCs = {}
for line in emcfile.readlines():
    line = line.split(',')
    if line[0].lower() != 'gridcode':
        EMCs[int(line[0])] = [line[1]] + map(float,line[2:])
 
#arcpy.AddMessage(str(EMCs))



gp.env.overwriteOutput = True
#gp.env.workspace = r'C:\WorkSpace\497 Project Tools\Outputs'

# Used to determine ArcGIS version
d = gp.GetInstallInfo()

version = " \nArcGIS %s : %s" % ('Version', d.get('Version','Version Unknown'))
print version

if version.find("10.") > 0:
    ArcGIS10 = True

else:
    ArcGIS10 = False

del d
   
if version < 9.3:
    arcpy.AddMessage("\nThis tool requires ArcGIS version 9.3 or Greater.....EXITING",2)
    sys.exit("")           


try:
    # Check out Spatial Analyst License        
    if gp.CheckExtension("spatial") == "Available":
        gp.CheckOutExtension("spatial")
    else:
        gp.AddError("Spatial Analyst Extension not enabled. Please enable Spatial analyst and try again.... ...EXITING")
        sys.exit("")

    # ---------------------------------------------------------------------- Input Parameters
    arcpy.AddMessage("Getting inputs")
    inLandUse = gp.GetParameterAsText(0)
    inRunoff = gp.GetParameterAsText(1)
    outTable = gp.GetParameterAsText(2)
    outLayer = gp.GetParameterAsText(3)

    
    snapRaster = inRunoff
        
    # If snap raster provided assign output cell size from snapRaster
    arcpy.AddMessage("Running Checks")
    if len(snapRaster) > 0:
        if gp.Exists(snapRaster):
            desc = gp.Describe(snapRaster)
            sr = desc.SpatialReference
            outCellSize = desc.MeanCellWidth
            outCoordSys = sr
            del desc, sr
        else:
            arcpy.AddMessage("\n\nSpecified Snap Raster Does not exist, please make another selection or verify the path...EXITING",2)
            sys.exit("")
            
            
    if not outTable and not outLayer:
        gp.AddError("No Outputs Defined")
        #sys.exit("")

    # ---------------------------------------------------------------------------
    arcpy.AddMessage("Raster Calculations")
    ws = arcpy.env.scratchWorkspace 
    if '.gdb' in ws:
        arcpy.env.scratchWorkspace  = os.path.dirname(ws)
        arcpy.AddMessage("Changed scratch workspace to " + arcpy.env.scratchWorkspace)
        arcpy.AddMessage("This change is necessary to avoid crashes")
    #arcpy.env.workspace = os.path.dirname(arcpy.env.workspace)
    #arcpy.env.workspace = 'in_memory'
    #arcpy.AddMessage("wsp = " + arcpy.env.workspace)
    #arcpy.gp.RasterCalculator_sa('Int(\"'+str(inLandUse)+'\")', 'intLanduse')
    intLanduse = arcpy.sa.Int(inLandUse)
    
    multval = 1000
    Runoffmult = arcpy.sa.Times(inRunoff, 100)
    #Runoffround = arcpy.sa.RoundUp(Runoffmult)
    #arcpy.gp.RasterCalculator_sa('Int(\"'+str(Runoffround)+'\")', 'intRunoff')
    intRunoff = arcpy.sa.Int(Runoffmult)
    #arcpy.AddMessage("Times")
    Runoffmult2 = arcpy.sa.Times(intRunoff, multval)
    
    arcpy.AddMessage("Plus")
    #arcpy.Plus_3d(Runoffmult2, intLanduse, 'combined.tif')
    runoffPlus = arcpy.sa.Plus(intLanduse,Runoffmult2)
    #arcpy.gp.RasterCalculator_sa('Int(\"'+str(runoffPlus)+'\")', 'intCombined')
    arcpy.AddMessage("Copy")
    #cursor2 = arcpy.da.SearchCursor(runoffPlus, 
    #arcpy.CopyRaster_management(runoffPlus,'combined')
    
    arcpy.AddMessage("Creating Cursor")
    cursor = arcpy.SearchCursor(runoffPlus)
    arcpy.AddMessage("Starting Iteration")
    runoffs = {}
    for row in cursor:
        
        Landuse = row.value % multval# %multval #tools.getLandUseGroup(row.value) #get land use
        runoff = math.trunc(row.value / multval)/100.0
        arcpy.AddMessage("Iterating on Landuse " + str(Landuse) + ' and runoff ' + str(runoff) + 'mm depth')
        
        runoffVol = runoff * outCellSize * outCellSize # mm * m * m = L
        if runoffs.get(Landuse, 0) == 0:
            runoffs[Landuse] = [0 for x in range(8)]
        
        arcpy.AddMessage(str(EMCs[Landuse]))
        EMC_TSS = runoffVol * EMCs[Landuse][5]#mg
        EMC_TP = runoffVol * EMCs[Landuse][6]#mg
        EMC_TN = runoffVol * EMCs[Landuse][7]#mg
        EMC_TLead = runoffVol * EMCs[Landuse][8]#ug
        EMC_TCopper = runoffVol * EMCs[Landuse][9]#ug
        EMC_TZinc = runoffVol * EMCs[Landuse][10]#ug
        E_coli = runoffVol * EMCs[Landuse][11] * 10#MPN
        
        runoffs[Landuse][0] += runoffVol
        runoffs[Landuse][1] += EMC_TSS
        runoffs[Landuse][2] += EMC_TP
        runoffs[Landuse][3] += EMC_TN
        runoffs[Landuse][4] += EMC_TLead
        runoffs[Landuse][5] += EMC_TCopper
        runoffs[Landuse][6] += EMC_TZinc
        runoffs[Landuse][7] += E_coli
        
    if outTable:
        arcpy.CreateTable_management(os.path.dirname(outTable), os.path.basename(outTable))
        #arcpy.TableToTable_conversion(['landuse,avg_runoff,avg_tss,avg_tp,avg_tn,avg_tlead,avg_tcoppr,avg_tzinc,avg_ecoli'], arcpy.env.workspace, outTable)
        arcpy.AddField_management(outTable, "landuse", "FLOAT", "", "", "", "Landuse", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(outTable, "avg_runoff", "FLOAT", "", "", "", "Avg Annual Runoff (L)", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(outTable, "avg_tss", "FLOAT", "", "", "", "Avg Annual Suspended Solids (mg)", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(outTable, "avg_tp", "FLOAT", "", "", "", "Avg Annual Phosphorous (mg)", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(outTable, "avg_tn", "FLOAT", "", "", "", "Avg Annual Nitrogen (mg)", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(outTable, "avg_tlead", "FLOAT", "", "", "", "Avg Annual Lead (ug)", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(outTable, "avg_tcoppr", "FLOAT", "", "", "", "Avg Annual Copper (ug)", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(outTable, "avg_tzinc", "FLOAT", "", "", "", "Avg Annual Zinc (ug)", "NULLABLE", "REQUIRED")
        arcpy.AddField_management(outTable, "avg_ecoli", "FLOAT", "", "", "", "E coli (MPN)", "NULLABLE", "REQUIRED")
        cursor = arcpy.InsertCursor(outTable)
        for k in runoffs.keys():
            row = cursor.newRow() 
            row.landuse = k
            row.avg_runoff = runoffs[k][0]
            row.avg_tss = runoffs[k][1]
            row.avg_tp = runoffs[k][2]
            row.avg_tn = runoffs[k][3]
            row.avg_tlead = runoffs[k][4]
            row.avg_tcoppr = runoffs[k][5]
            row.avg_tzinc = runoffs[k][6]
            row.avg_ecoli = runoffs[k][7]
            cursor.insertRow(row) 
    
    if outLayer:
        arcpy.gp.RasterCalculator_sa('Int(\"'+str(runoffPlus)+'\")', 'intRaster')
        allzs = arcpy.sa.Times('intRaster', 0)
        arcpy.RasterToPolygon_conversion(allzs, 'xlayer', "NO_SIMPLIFY",'Value')
        arcpy.CopyFeatures_management ('xlayer', outLayer, "", "", "", "")
        arcpy.AddField_management(outLayer, "avg_runoff", "FLOAT", "", "", "", "Avg Annual Runoff (L)", "NULLABLE", "NON_REQUIRED")
        arcpy.AddField_management(outLayer, "avg_tss", "FLOAT", "", "", "", "Avg Annual Suspended Solids (mg)", "NULLABLE", "NON_REQUIRED")
        arcpy.AddField_management(outLayer, "avg_tp", "FLOAT", "", "", "", "Avg Annual Phosphorous (mg)", "NULLABLE", "NON_REQUIRED")
        arcpy.AddField_management(outLayer, "avg_tn", "FLOAT", "", "", "", "Avg Annual Nitrogen (mg)", "NULLABLE", "NON_REQUIRED")
        arcpy.AddField_management(outLayer, "avg_tlead", "FLOAT", "", "", "", "Avg Annual Lead (ug)", "NULLABLE", "NON_REQUIRED")
        arcpy.AddField_management(outLayer, "avg_tcoppr", "FLOAT", "", "", "", "Avg Annual Copper (ug)", "NULLABLE", "NON_REQUIRED")
        arcpy.AddField_management(outLayer, "avg_tzinc", "FLOAT", "", "", "", "Avg Annual Zinc (ug)", "NULLABLE", "NON_REQUIRED")
        arcpy.AddField_management(outLayer, "avg_ecoli", "FLOAT", "", "", "", "E coli (MPN)", "NULLABLE", "NON_REQUIRED")
        
        totals = [0,0,0,0,0,0,0,0]
        for k in runoffs.keys():
            totals[0] += runoffs[k][0]
            totals[1] += runoffs[k][1]
            totals[2] += runoffs[k][2]
            totals[3] += runoffs[k][3]
            totals[4] += runoffs[k][4]
            totals[5] += runoffs[k][5]
            totals[6] += runoffs[k][6]
            totals[7] += runoffs[k][7]
            
        cursor = arcpy.UpdateCursor(outLayer)
        for row in cursor:
            row.avg_runoff = totals[0]
            row.avg_tss = totals[1]
            row.avg_tp = totals[2]
            row.avg_tn = totals[3]
            row.avg_tlead = totals[4]
            row.avg_tcoppr = totals[5]
            row.avg_tzinc = totals[6]
            row.avg_ecoli = totals[7]
            cursor.updateRow(row) 
        
    arcpy.AddMessage("Finished")
    arcpy.env.scratchWorkspace  = ws
    
except SystemExit:
    pass

except KeyboardInterrupt:
    arcpy.AddMessage("Interruption requested....exiting")

except:
    print_exception()    
