def print_exception():
    
    tb = sys.exc_info()[2]
    l = traceback.format_tb(tb)
    l.reverse()
    tbinfo = "".join(l)
    arcpy.AddError("\n----------ERROR Start-------------------\n")
    arcpy.AddError("Traceback Info: \n" + tbinfo + "Error Info: \n    " +  str(sys.exc_type)+ ": " + str(sys.exc_value) + "")
    arcpy.AddError("----------ERROR End-------------------- \n")

def average(l):
    avg = 0
    cnt = 0
    for i in l:
        cnt += 1
        avg += i
    return avg / cnt
    
## ================================================================================================================
# Import system modules
import sys, os, string, traceback
import arcpy as gp

arcpy.AddMessage("Establishing Data Values")
gp.env.overwriteOutput = True
gp.env.workspace = r'C:\WorkSpace\497 Project Tools\Outputs'

# Used to determine ArcGIS version
d = gp.GetInstallInfo()

version = " \nArcGIS %s : %s" % ('Version', d.get('Version','Version Unknown'))
print version

if version.find("10.") > 0:
    ArcGIS10 = True

else:
    ArcGIS10 = False

del d
   
if version < 9.3:
    arcpy.AddMessage("\nThis tool requires ArcGIS version 9.3 or Greater.....EXITING",2)
    sys.exit("")           


try:
    # Check out Spatial Analyst License        
    if gp.CheckExtension("spatial") == "Available":
        gp.CheckOutExtension("spatial")
    else:
        gp.AddError("Spatial Analyst Extension not enabled. Please enable Spatial analyst and try again.... ...EXITING")
        sys.exit("")


        
    # ---------------------------------------------------------------------- Input Parameters
    
    inRaster = gp.GetParameterAsText(0)
    outFeature = gp.GetParameterAsText(1)

    # ---------------------------------------------------------------------------
    
    #arcpy.gp.RasterCalculator_sa('Int(\"'+str(inRaster)+'\")', 'intRaster')
    intRaster = arcpy.sa.Int(str(inRaster))
    allzs = arcpy.sa.Times(intRaster, 0)
    arcpy.RasterToPolygon_conversion(allzs, outFeature, "NO_SIMPLIFY",'Value')
    
    arcpy.AddMessage("Finished")
    
except SystemExit:
    pass

except KeyboardInterrupt:
    arcpy.AddMessage("Interruption requested....exiting")

except:
    print_exception()    
