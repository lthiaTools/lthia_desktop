def print_exception():
    
    tb = sys.exc_info()[2]
    l = traceback.format_tb(tb)
    l.reverse()
    tbinfo = "".join(l)
    arcpy.AddError("\n----------ERROR Start-------------------\n")
    arcpy.AddError("Traceback Info: \n" + tbinfo + "Error Info: \n    " +  str(sys.exc_type)+ ": " + str(sys.exc_value) + "")
    arcpy.AddError("----------ERROR End-------------------- \n")

def average(l):
    avg = 0
    cnt = 0
    for i in l:
        cnt += 1
        avg += i
    return avg / cnt
    
## ================================================================================================================
# Import system modules
import sys, os, string, traceback
import arcpy as gp

arcpy.AddMessage("Establishing Data Values")
gp.env.overwriteOutput = True
#gp.env.workspace = r'C:\WorkSpace\497 Project Tools\Outputs'

# Used to determine ArcGIS version
d = gp.GetInstallInfo()

version = " \nArcGIS %s : %s" % ('Version', d.get('Version','Version Unknown'))
print version

if version.find("10.") > 0:
    ArcGIS10 = True

else:
    ArcGIS10 = False

del d
   
if version < 9.3:
    arcpy.AddMessage("\nThis tool requires ArcGIS version 9.3 or Greater.....EXITING",2)
    sys.exit("")           


try:
    # Check out Spatial Analyst License        
    if gp.CheckExtension("spatial") == "Available":
        gp.CheckOutExtension("spatial")
    else:
        gp.AddError("Spatial Analyst Extension not enabled. Please enable Spatial analyst and try again.... ...EXITING")
        sys.exit("")


        
    # ---------------------------------------------------------------------- Input Parameters
    
    inCNMap = gp.GetParameterAsText(0)
    arcpy.env.outputCoordinateSystem = arcpy.Describe(inCNMap).spatialReference
    inRainfall = gp.GetParameterAsText(1)
    inDetermine = gp.GetParameterAsText(2)
    inConditions = gp.GetParameterAsText(3)
    outRunoff = gp.GetParameterAsText(4)
    arcpy.AddMessage('CN Map: '+inCNMap + '\nRainfall: ' + inRainfall)
    tempClpRain = r'tempClpRain'#.shp'
    newCNMap = r'tempCNMap'
    rainRast = r'rainRast'#.tif'
    output = r'combinedData'#.tif'
    snapRaster = inCNMap
    mapPoly = r'mapPoly'#.shp'

    
        
    # If snap raster provided assign output cell size from snapRaster
    if len(snapRaster) > 0:
        if gp.Exists(snapRaster):
            desc = gp.Describe(snapRaster)
            sr = desc.SpatialReference
            outCellSize = desc.MeanCellWidth
            outCoordSys = sr
            del desc, sr
        else:
            arcpy.AddMessage("\n\nSpecified Snap Raster Does not exist, please make another selection or verify the path...EXITING",2)
            sys.exit("")

    # ---------------------------------------------------------------------------
    ws = arcpy.env.workspace
    #arcpy.env.workspace = "in_memory"
    inCNData = arcpy.Raster(inCNMap)
    if not inCNData.isInteger:
        arcpy.AddMessage("Itegerizing CN Map")
        inCNMap = arcpy.sa.Int(inCNMap)
    
    arcpy.AddMessage("Interpreting Precip Layer")
    arcpy.AddField_management(inRainfall, "accessval", "SHORT", "", "", "", "accessval", "NULLABLE", "REQUIRED")
    
    tableLinks = []
    cursor = arcpy.UpdateCursor(inRainfall)
    cnt = 0
    for row in cursor:
        tableLinks +=[[row.precip_table,row.table_unit]]
        row.accessval = cnt
        cnt += 1
        cursor.updateRow(row)
    
    if inDetermine == "CN Map":
        arcpy.AddMessage("Clipping Rainfall to CN Map")

        allzs = arcpy.sa.Times(inCNMap, 0)
        arcpy.RasterToPolygon_conversion(allzs, mapPoly, "NO_SIMPLIFY",'Value')
    
        arcpy.AddMessage("Performing Raster Math")# + str(outCellSize))
    
        arcpy.Clip_analysis(inRainfall, mapPoly, tempClpRain, "")
        arcpy.FeatureToRaster_conversion(tempClpRain, "accessval", rainRast, outCellSize)
        newCNMap = inCNMap
    else:
        arcpy.AddMessage("Clipping CN Map to Rainfall")

        arcpy.Clip_management(inCNMap,"#",newCNMap, inRainfall, "#", "NONE")

        #allzs = arcpy.sa.Times(newCNMap, 0)
        #arcpy.RasterToPolygon_conversion(allzs, mapPoly, "NO_SIMPLIFY",'Value')
    
        #arcpy.Clip_analysis(inRainfall, mapPoly, tempClpRain, "")
        arcpy.FeatureToRaster_conversion(inRainfall, "accessval", rainRast, outCellSize)
    
    multval = 1000
    Rainmult = arcpy.sa.Times(rainRast, multval)
      #Rainround = arcpy.sa.RoundUp(Rainmult)
      #arcpy.AddMessage("Test " + str(Rainround))
    intRainRast = arcpy.sa.Int(Rainmult)
      #arcpy.gp.RasterCalculator_sa('Int(\"'+str(Rainmult)+'\")', intRainRast)
      #Rainmult2 = arcpy.sa.Times(intRainRast, multval)
    arcpy.Plus_3d(intRainRast, newCNMap, output)
    
    arcpy.AddMessage("Creating Update Cursor")
    
    rows = arcpy.SearchCursor(output) #an iterator of the rows of the raster
    #iterate over the rows
    arcpy.AddMessage("Beginning Iteration")
    #arcpy.AddMessage("orig: " + str(arcpy.Describe(inRainfall).catalogPath))
    #ws = arcpy.env.workspace
    arcpy.env.workspace = os.path.dirname(os.path.realpath(arcpy.Describe(inRainfall).catalogPath))
    location = arcpy.env.workspace
    arcpy.AddMessage("Looking for tables in: " + arcpy.env.workspace)
    origOutput = output
    for row in rows:
        
        CN = row.value % multval# %multval #tools.getLandUseGroup(row.value) #get land use
        
        if inConditions.lower() == 'soils are dry':
            CN = CN / (2.281 - 0.0128 * CN)
        elif inConditions.lower() == 'soils are wet':
            CN = CN / (0.427 - 0.0057 * CN)
        
        rain = int(row.value / multval)

        table = tableLinks[rain][0]
        unit = tableLinks[rain][1]#'in'
        arcpy.AddMessage("Iterating on CN " + str(CN) + " and reading " + str(table) + ' (' + str(unit) +')')
        #arcpy.AddMessage("Rading: " + str(table) + ', ' + str(unit))
        TBV = arcpy.mapping.TableView(table)
        cols = []
        
        for r in arcpy.Describe(TBV).table.fields:
            #arcpy.AddMessage( "%-22s %s %s" % (r.name, ":", r.type))
            if r.type != 'OID':
                cols += [r.name]
            #arcpy.AddMessage("value of r: " + str(x) + ': ' + str(y))
            
        TBC = arcpy.SearchCursor(table)

        pcp = [[] for x in cols]
        for r in TBC:
            for i in range(len(cols)):

                rain = r.getValue(cols[i])
                if unit.lower() == 'in' or unit.lower() == 'inches':
                    rain += rain * 25.4
                
                
                
                HruRunoff = 0.0
                if rain > 0.0 :
                    if CN < 1 :
                        S = rain * 1000
                    else :
                        S = ( 25400 / CN ) - 254
                    if (0.2 * S) < rain :
                        HruRunoff = ((rain - (0.2 * S)) ** 2) / (rain + (0.8 * S))        #depth, mm
                
                    #arcpy.AddMessage("Pair: " + str(CN) + ': ' + str(HruRunoff) + '  (' + str(S) + ',' + str(rain) + ')')
                
                pcp[i] += [HruRunoff]
                
        years = [sum(x) for x in pcp]

        arcpy.env.workspace = ws
        output = arcpy.sa.Con(output, average(years), output, "VALUE = " + str(row.value))
        arcpy.env.workspace = location

    arcpy.env.workspace = ws
    arcpy.CopyRaster_management(output,outRunoff)
    arcpy.AddMessage("Finished Iteration\nCleaning up")

    try:
        tempItems = (tempClpRain, rainRast, origOutput, mapPoly)
        for item in tempItems:
            arcpy.Delete_management(item)
    except arcpy.ExecuteError as e:
        if '000732' in e.message:
            pass
        else:
            raise e

    arcpy.env.workspace = ws
       
    
except SystemExit:
    pass

except KeyboardInterrupt:
    arcpy.AddMessage("Interruption requested....exiting")

except:
    print_exception()    
