********************************************************************************
*                                                                              *
*                     Desktop L-THIA ArcMap Toolbox                            *
*                                                                              *
********************************************************************************
General Description
-   Suite of scripts to facilitate running the L-THIA model within ArcMap. Built in 10.2, runs in 10.1.
-   Includes the model itself as well as tools to generate precipitation
-   layers, CN Maps, and outlines of rasters. The precip layer tool has two options including links to fetch our online precip data.


Installation
-   To access this toolbox in ArcMap, simply place this directory in your 
-   preferred directory. Everything should then be accessible via the Catalog
-   tab. (Windows -> Catalog) Depending on where you placed the directory you 
-   may need to press the "Connect to Folder" button and navigate to it so the
-   Catalog can access it. Once the toolbox is visible, all scripts can be
-   be run by manually from there. (Right Click -> Open...)

Troubleshooting: Do not rename the lthia.gdb file geodatabase. For computational reasons, all your layers (input and output) should be in a file geodatabase including the soil raster and the NLCD landuse. This means you should assign output to a file geodatabase when you create the watershed-sized subsets for HSG soil and landuse which you intend to run the tools upon. Not required they go into lthia.gdb, just that they are in some file geodatabase.

Toolbox Breakdown:
1: CN Map
Generate CN Map (genCNMap.py)       
    Inputs:   
        -   Land Use Raster
        -   Soil Type Raster
        -   Output CN Raster (User specified name/location)
    Output
        -   CN Map compatible with the 'Calculate EMC Values' tool

Generate Raster Outline (Compute Region Outline.py)
    Inputs:   
        -   Input Raster
        -   Output Feature
    Output
        -   Feature Layer that is the approximated outline of the input Raster Layer

2. Precipitation

Generate CLIGEN Precipitation Feature Layer (getCligen.py)
    Inputs:
        -   Watershed to be analyzed (As feature)
        -   (hidden) Uses "CligenFeature" Layer (CligenFeatureBig is provided, this is all CLIGEN stations in the continental US with 50 years of precipitaiton generated. You can select only the cligen stations you want to use. Delete the existing "CligenFeature", then edit CligenStationsUS by selecting only the point stations you want to use, run the "Generate Theissen Polygons" tool on the selection output, saving it in the lthia file geodatabase under the name "CligenFeature" (name is case sensitive). 

        -   Hidden: Units of Cligen Precip File(s) is millimeters
        -   Output Layer (User specified name and location for output precipitation Feature Layer)
    Output:
        -   Feature Layer that is essentially the original watershed
            with rainfall data associated with it (using ArcMap TableViews)

Generate Precipitation Feature Layer (genPrecip.py)
    Inputs:
        -   Watershed to be analyzed (As feature)

	Choose either this
        -   Rainfall Detail Layer (PrecipZonesURL is provided, this file has links the script will use to download precipitation data observed between 1963- 1993) The spatial locations of the observation gauges were joined to county centers, such that every county has an output file with 30 years of observed data from the nearest gauge. This script will select all the locations needed for your watershed and fetch the precipitation data from the L-thia server. You may build your own layer from gauges you desire to use by editing ( e.g. select desired points and export) the point location file "LthiaCtyStations". Delete the layer PrecipZonesURL and run the "Generate Theissen Polygons" tool, directing the output to lthia.gdb and naming the output "PrecipZonesURL". The result is a selected set of our gauges which will download from the L-thia server. To use your own gauges and not download our precipitation data, see below.

***   -OR choose this - 
        -   Precipitation File  (Overrides Rainfall Detail Layer with your single gauge precipitation file) Your gauge data must match expected format.

        -   Units of Precip File(s) (inches or millimeters)
        -   Output Layer (User specified name and location for output Feature Layer)
    Output:
        -   Feature Layer that is essentially the original watershed
            with rainfall data associated with it (using ArcMap TableViews)

Generate Thiessen Rainfall Polygons (genThiesen.py)
    Inputs:
        -   Rainfall Gauge Locations (points, with associated rainfall urls)
        -   Output Layer (User specified name and location for output Feature Layer)
    Output:
        -   A Feature Layer that is a 'Rainfall Detail Layer' compatible with the 
            'Generate Precipitation Feature Layer' script. Creates Thiessen polygons
            based on the locations of Rainfall Gauges and associates a Precipitation
            file URL with them.
            
3. LTHIA
Generate Runoff Map (Generate Runoff.py)
    Inputs:   
        -   CN Map
        -   Rainfall Feature (Format conforming to our Precipitation tool)
        -   Soil Moisture Classification (normal, dry, or wet)
        -   Output Runoff Raster (User specified name and location)
    Output:
        -   Raster Layer that is a raster map with calculated runoff values
            based on daily calculation from associated rainfall data, in depth as mm / pixel
            
Calculate EMC Values (CalculateEmc.py)
    Inputs:   
        -   Landuse Raster
        -   Runoff Raster (Generated from previous tool)
        -   Output Table (Specified for output in table format)
        -   Output Feature (Specified for output as a Feature Layer)
	-	hidden: EMC table used is the text file cnemc.csv, which user may edit.
    Output
        -   EMC values, output as a Table or Feature Layer (or both) as 
            specified by the user.
        
 
    

            
        
        
        
        
        
        
        
        
        
        
        